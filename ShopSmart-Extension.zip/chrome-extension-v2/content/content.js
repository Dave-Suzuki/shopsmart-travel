/**
 * ShopSmart Travel Content Script
 * Detects product/cart pages and provides scraping functionality
 */

(function() {
  'use strict';

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getPageType') {
      sendResponse({
        isProduct: isProductPage(),
        isCart: isCartPage()
      });
    } else if (request.action === 'scrapeProduct') {
      const product = scrapeProduct();
      sendResponse({ product });
    } else if (request.action === 'scrapeCart') {
      const items = scrapeCart();
      sendResponse({ items });
    }
    return true;
  });

  function isProductPage() {
    // Check for product indicators
    const hasAddToCart = !!document.querySelector('[class*="add-to-cart"], [id*="add-to-cart"], button[name="add"], [data-action="add-to-cart"]');
    const hasProductSchema = !!document.querySelector('script[type="application/ld+json"]');
    const hasProductMeta = !!document.querySelector('meta[property="og:type"][content="product"], meta[property="product:price:amount"]');
    const hasPrice = !!document.querySelector('[class*="price"], [itemprop="price"]');

    return hasAddToCart || (hasProductSchema && hasPrice) || hasProductMeta;
  }

  function isCartPage() {
    const url = window.location.href.toLowerCase();
    const pathname = window.location.pathname.toLowerCase();

    return url.includes('/cart') ||
           url.includes('/basket') ||
           url.includes('/bag') ||
           pathname.includes('cart') ||
           pathname.includes('checkout') ||
           !!document.querySelector('[class*="cart-item"], [class*="basket-item"], [data-cart-item]');
  }

  function scrapeProduct() {
    let product = {};

    // Try JSON-LD first
    const jsonLd = document.querySelector('script[type="application/ld+json"]');
    if (jsonLd) {
      try {
        const data = JSON.parse(jsonLd.textContent);
        const productData = data['@type'] === 'Product' ? data :
                           (Array.isArray(data['@graph']) ? data['@graph'].find(item => item['@type'] === 'Product') : null);

        if (productData) {
          product.name = productData.name;
          product.brand = productData.brand?.name || productData.brand;
          product.description = productData.description;
          product.imageUrl = Array.isArray(productData.image) ? productData.image[0] : productData.image;

          if (productData.offers) {
            const offer = Array.isArray(productData.offers) ? productData.offers[0] : productData.offers;
            product.price = parseFloat(offer.price);
            product.currency = offer.priceCurrency || 'USD';
          }
        }
      } catch (e) {
        console.debug('JSON-LD parse error:', e);
      }
    }

    // Try Open Graph tags
    if (!product.name) {
      product.name = document.querySelector('meta[property="og:title"]')?.content ||
                     document.querySelector('h1')?.textContent?.trim();
    }

    if (!product.imageUrl) {
      product.imageUrl = document.querySelector('meta[property="og:image"]')?.content;
    }

    if (!product.price) {
      const priceEl = document.querySelector('[itemprop="price"]') ||
                      document.querySelector('meta[property="product:price:amount"]') ||
                      document.querySelector('[class*="price"]:not([class*="was"]):not([class*="original"])');

      if (priceEl) {
        const priceText = priceEl.content || priceEl.textContent;
        const priceMatch = priceText?.match(/[\d,.]+/);
        if (priceMatch) {
          product.price = parseFloat(priceMatch[0].replace(',', ''));
        }
      }
    }

    if (!product.currency) {
      product.currency = document.querySelector('meta[property="product:price:currency"]')?.content || 'USD';
    }

    product.productUrl = window.location.href;

    return product;
  }

  function scrapeCart() {
    const items = [];

    // Shopify cart
    if (window.Shopify) {
      return scrapeShopifyCart();
    }

    // Generic cart scraping
    const cartItems = document.querySelectorAll('[class*="cart-item"], [class*="basket-item"], [class*="line-item"], [data-cart-item]');

    cartItems.forEach((item, index) => {
      const nameEl = item.querySelector('[class*="name"], [class*="title"], h2, h3, a');
      const priceEl = item.querySelector('[class*="price"]');
      const imageEl = item.querySelector('img');
      const qtyEl = item.querySelector('input[type="number"], [class*="quantity"]');

      if (nameEl) {
        const priceText = priceEl?.textContent || '';
        const priceMatch = priceText.match(/[\d,.]+/);

        items.push({
          name: nameEl.textContent?.trim(),
          price: priceMatch ? parseFloat(priceMatch[0].replace(',', '')) : null,
          currency: 'USD',
          imageUrl: imageEl?.src,
          quantity: parseInt(qtyEl?.value || qtyEl?.textContent) || 1,
          productUrl: nameEl.href || window.location.href
        });
      }
    });

    return items;
  }

  async function scrapeShopifyCart() {
    try {
      const response = await fetch('/cart.js');
      const cart = await response.json();

      return cart.items.map(item => ({
        name: item.title,
        price: item.price / 100,
        currency: cart.currency || 'USD',
        imageUrl: item.image,
        quantity: item.quantity,
        brand: item.vendor,
        productUrl: window.location.origin + item.url
      }));
    } catch (e) {
      console.error('Shopify cart scrape error:', e);
      return [];
    }
  }

  console.log('ShopSmart content script loaded');
})();
