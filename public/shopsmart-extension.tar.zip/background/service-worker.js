/**
 * ShopSmart Travel Background Service Worker
 */

const SHOPSMART_URL = 'https://shopsmart-800cb.web.app';

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('ShopSmart Travel extension installed');
    chrome.storage.local.set({ trips: [], defaultTripId: null });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getTripId') {
    chrome.storage.local.get(['defaultTripId'], (result) => {
      sendResponse({ tripId: result.defaultTripId });
    });
    return true;
  }

  if (request.action === 'getTrips') {
    chrome.storage.local.get(['trips'], (result) => {
      sendResponse({ trips: result.trips || [] });
    });
    return true;
  }
});
